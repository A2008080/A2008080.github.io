@echo off
chcp 65001 >nul
title 英语家教工作台
cd /d "%~dp0"
echo.
echo  ========================================
echo   英语家教工作台 - 正在启动...
echo  ========================================
echo.
echo  浏览器即将打开，请不要关闭此窗口。
echo  如需关闭工作台，请关闭此窗口即可。
echo.
start "" "http://localhost:8765"
python -m http.server 8765
pause
