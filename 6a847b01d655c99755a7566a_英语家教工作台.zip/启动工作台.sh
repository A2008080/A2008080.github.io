#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "  ======================================== "
echo "   英语家教工作台 - 正在启动..."
echo "  ======================================== "
echo ""
echo "  浏览器即将打开，请不要关闭此终端窗口。"
echo ""
# 尝试打开浏览器
if command -v open &>/dev/null; then
  open "http://localhost:8765" &
elif command -v xdg-open &>/dev/null; then
  xdg-open "http://localhost:8765" &
fi
python3 -m http.server 8765
